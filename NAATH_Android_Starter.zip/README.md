# NAATH Android starter (private demo)

This is a first React Native / Expo prototype for NAATH. It is not a production marketplace.

## Run it from a phone using Expo Snack

1. Open https://snack.expo.dev in your browser.
2. Create a new Snack.
3. Replace the contents of `App.js` with the contents of the included `App.js`.
4. Select Android in the preview controls.
5. To run it on your Android phone, install Expo Go from Google Play and use Snack's Expo Go preview option if available.

## Included in this demo
- Fashion catalogue and category filters
- Search
- Shopping bag with quantity controls
- Checkout form with simulated payment choices
- Demo order confirmation
- Seller registration preview

## Important limitations
- Sample products and prices only.
- Data is held in temporary app state and is not saved to a database.
- No real login, seller accounts, messages, orders, payments, delivery booking, refunds or notifications.
- Never enter a real Mobile Money PIN or card details.
- This project does not contain an APK. A private APK requires a separate Android build step.
- For production, add a secure backend, authentication, database, access controls, payment verification and testing.
