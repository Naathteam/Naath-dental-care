import React, { useMemo, useState } from "react";
import {
  SafeAreaView, View, Text, TextInput, ScrollView, Pressable,
  StyleSheet, StatusBar, Alert
} from "react-native";

const PRODUCTS = [
  { id: "P001", name: "Classic Everyday Hoodie", category: "Men", price: 85000, emoji: "🧥", district: "Kampala" },
  { id: "P002", name: "Elegant Ankara Dress", category: "Women", price: 95000, emoji: "👗", district: "Wakiso" },
  { id: "P003", name: "Leather Fashion Handbag", category: "Bags", price: 70000, emoji: "👜", district: "Kampala" },
  { id: "P004", name: "Streetwear Sneakers", category: "Shoes", price: 120000, emoji: "👟", district: "Mukono" },
  { id: "P005", name: "Summer Casual Top", category: "Women", price: 45000, emoji: "👚", district: "Jinja" },
  { id: "P006", name: "Men's Smart Shirt", category: "Men", price: 65000, emoji: "👔", district: "Mbarara" },
];

const money = n => `UGX ${Number(n).toLocaleString("en-UG")}`;

function ActionButton({ title, onPress, secondary = false }) {
  return (
    <Pressable onPress={onPress} style={[styles.button, secondary && styles.secondaryButton]}>
      <Text style={[styles.buttonText, secondary && styles.secondaryButtonText]}>{title}</Text>
    </Pressable>
  );
}

export default function App() {
  const [tab, setTab] = useState("Home");
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [cart, setCart] = useState({});
  const [customer, setCustomer] = useState("");
  const [phone, setPhone] = useState("");
  const [district, setDistrict] = useState("Kampala");
  const [delivery, setDelivery] = useState("Home delivery");
  const [payment, setPayment] = useState("MTN Mobile Money");
  const [sellerName, setSellerName] = useState("");
  const [shopName, setShopName] = useState("");
  const [sellerPhone, setSellerPhone] = useState("");
  const [orderPlaced, setOrderPlaced] = useState(false);

  const cartItems = Object.entries(cart)
    .filter(([, qty]) => qty > 0)
    .map(([id, qty]) => ({ ...PRODUCTS.find(p => p.id === id), qty }));
  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.qty, 0);
  const count = cartItems.reduce((sum, item) => sum + item.qty, 0);

  const filtered = useMemo(() => PRODUCTS.filter(p =>
    (category === "All" || p.category === category) &&
    `${p.name} ${p.category} ${p.district}`.toLowerCase().includes(query.toLowerCase())
  ), [category, query]);

  const add = id => setCart(old => ({ ...old, [id]: (old[id] || 0) + 1 }));
  const change = (id, delta) => setCart(old => ({ ...old, [id]: Math.max(0, (old[id] || 0) + delta) }));

  const placeDemoOrder = () => {
    if (!customer.trim() || !phone.trim()) {
      Alert.alert("A little more information", "Enter your name and phone number to continue.");
      return;
    }
    if (!count) {
      Alert.alert("Your bag is empty", "Add a product before checking out.");
      return;
    }
    setOrderPlaced(true);
    setCart({});
    setTab("Orders");
    Alert.alert("Demo order created", "Your sample order reference is NAATH-DEMO-001. No payment has been taken.");
  };

  const Header = () => (
    <View style={styles.header}>
      <View>
        <Text style={styles.brand}>NAATH</Text>
        <Text style={styles.tagline}>Fashion finds, made in Uganda 🇺🇬</Text>
      </View>
      <Pressable style={styles.cartBubble} onPress={() => setTab("Bag")}>
        <Text style={styles.cartBubbleText}>🛍️ {count}</Text>
      </Pressable>
    </View>
  );

  const ProductCard = ({ item }) => (
    <View style={styles.productCard}>
      <View style={styles.productArt}><Text style={styles.productEmoji}>{item.emoji}</Text></View>
      <Text style={styles.productName}>{item.name}</Text>
      <Text style={styles.muted}>{item.category} · {item.district}</Text>
      <Text style={styles.price}>{money(item.price)}</Text>
      <ActionButton title="Add to bag" onPress={() => add(item.id)} />
    </View>
  );

  const Home = () => (
    <>
      <View style={styles.hero}>
        <Text style={styles.heroEyebrow}>DISCOVER YOUR STYLE</Text>
        <Text style={styles.heroTitle}>Your next favourite look starts here.</Text>
        <Text style={styles.heroSub}>Shop fashion from sellers across Uganda.</Text>
      </View>
      <TextInput value={query} onChangeText={setQuery} placeholder="Search clothes, shoes, bags..." placeholderTextColor="#8B8B8B" style={styles.search} />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categories}>
        {["All", "Women", "Men", "Shoes", "Bags"].map(c => (
          <Pressable key={c} onPress={() => setCategory(c)} style={[styles.chip, category === c && styles.chipActive]}>
            <Text style={[styles.chipText, category === c && styles.chipTextActive]}>{c}</Text>
          </Pressable>
        ))}
      </ScrollView>
      <View style={styles.sectionRow}>
        <Text style={styles.sectionTitle}>Popular fashion</Text>
        <Text style={styles.muted}>{filtered.length} items</Text>
      </View>
      <View style={styles.productGrid}>
        {filtered.map(p => <ProductCard key={p.id} item={p} />)}
      </View>
      <Text style={styles.disclaimer}>Demo catalogue · Sample products and prices only.</Text>
    </>
  );

  const Bag = () => (
    <View>
      <Text style={styles.pageTitle}>Your shopping bag</Text>
      {!cartItems.length ? <Text style={styles.empty}>Your bag is empty. Browse the catalogue and add something you love.</Text> : null}
      {cartItems.map(item => (
        <View key={item.id} style={styles.lineItem}>
          <Text style={styles.lineEmoji}>{item.emoji}</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.productName}>{item.name}</Text>
            <Text style={styles.price}>{money(item.price)}</Text>
            <View style={styles.qtyRow}>
              <Pressable onPress={() => change(item.id, -1)} style={styles.qtyButton}><Text>−</Text></Pressable>
              <Text style={styles.qty}>{item.qty}</Text>
              <Pressable onPress={() => change(item.id, 1)} style={styles.qtyButton}><Text>+</Text></Pressable>
            </View>
          </View>
        </View>
      ))}
      <View style={styles.totalRow}><Text style={styles.sectionTitle}>Subtotal</Text><Text style={styles.sectionTitle}>{money(subtotal)}</Text></View>
      <Text style={styles.muted}>Delivery fee is calculated separately and confirmed before checkout.</Text>
      <ActionButton title="Continue to checkout" onPress={() => setTab("Checkout")} />
    </View>
  );

  const Checkout = () => (
    <View>
      <Text style={styles.pageTitle}>Checkout · Demo</Text>
      <TextInput value={customer} onChangeText={setCustomer} placeholder="Your full name" style={styles.input} />
      <TextInput value={phone} onChangeText={setPhone} placeholder="Phone number" keyboardType="phone-pad" style={styles.input} />
      <Text style={styles.fieldLabel}>District</Text>
      <TextInput value={district} onChangeText={setDistrict} placeholder="e.g. Kampala" style={styles.input} />
      <Text style={styles.fieldLabel}>Delivery method</Text>
      <View style={styles.choiceRow}>
        {["Home delivery", "Seller pickup"].map(x => <Pressable key={x} onPress={() => setDelivery(x)} style={[styles.choice, delivery === x && styles.choiceActive]}><Text style={[styles.choiceText, delivery === x && styles.choiceTextActive]}>{x}</Text></Pressable>)}
      </View>
      <Text style={styles.fieldLabel}>Payment method (simulation only)</Text>
      {["MTN Mobile Money", "Airtel Money", "Cash on delivery"].map(x => <Pressable key={x} onPress={() => setPayment(x)} style={[styles.paymentChoice, payment === x && styles.choiceActive]}><Text style={[styles.choiceText, payment === x && styles.choiceTextActive]}>{payment === x ? "● " : "○ "}{x}</Text></Pressable>)}
      <View style={styles.totalRow}><Text style={styles.sectionTitle}>Merchandise subtotal</Text><Text style={styles.sectionTitle}>{money(subtotal)}</Text></View>
      <Text style={styles.disclaimer}>No real payment is processed. Delivery fee must be agreed before a real order.</Text>
      <ActionButton title="Place demo order" onPress={placeDemoOrder} />
    </View>
  );

  const Orders = () => (
    <View>
      <Text style={styles.pageTitle}>My orders</Text>
      {orderPlaced ? (
        <View style={styles.orderCard}>
          <Text style={styles.orderRef}>NAATH-DEMO-001</Text>
          <Text style={styles.productName}>Demo order received</Text>
          <Text style={styles.muted}>Status: Awaiting seller confirmation</Text>
          <Text style={styles.muted}>Payment: Not processed · Test only</Text>
          <View style={styles.progress}><View style={styles.progressFill} /></View>
        </View>
      ) : <Text style={styles.empty}>Your orders will appear here after checkout.</Text>}
    </View>
  );

  const Account = () => (
    <View>
      <Text style={styles.pageTitle}>Welcome to NAATH</Text>
      <Text style={styles.muted}>Customer and seller tools · Demonstration only</Text>
      <View style={styles.panel}>
        <Text style={styles.sectionTitle}>Seller registration preview</Text>
        <TextInput value={sellerName} onChangeText={setSellerName} placeholder="Your full name" style={styles.input} />
        <TextInput value={shopName} onChangeText={setShopName} placeholder="Shop name" style={styles.input} />
        <TextInput value={sellerPhone} onChangeText={setSellerPhone} placeholder="Phone number" keyboardType="phone-pad" style={styles.input} />
        <ActionButton title="Submit demo seller registration" onPress={() => {
          if (!sellerName.trim() || !shopName.trim() || !sellerPhone.trim()) {
            Alert.alert("Missing details", "Please fill in your name, shop name and phone number.");
          } else {
            Alert.alert("Demo registration received", "This has not been sent to a live marketplace.");
            setSellerName(""); setShopName(""); setSellerPhone("");
          }
        }} />
      </View>
      <View style={styles.panel}>
        <Text style={styles.sectionTitle}>NAATH marketplace rules</Text>
        <Text style={styles.bodyText}>• 5% commission on completed merchandise sales.</Text>
        <Text style={styles.bodyText}>• Delivery fees are separate.</Text>
        <Text style={styles.bodyText}>• No customer funds are held in a personal wallet.</Text>
      </View>
    </View>
  );

  const screens = { Home: <Home />, Bag: <Bag />, Checkout: <Checkout />, Orders: <Orders />, Account: <Account /> };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#F8F5F0" />
      <Header />
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {screens[tab]}
      </ScrollView>
      <View style={styles.nav}>
        {["Home", "Bag", "Orders", "Account"].map(name => (
          <Pressable key={name} onPress={() => setTab(name)} style={styles.navItem}>
            <Text style={[styles.navIcon, tab === name && styles.navSelected]}>{({Home:"⌂",Bag:"🛍",Orders:"▤",Account:"☺"})[name]}</Text>
            <Text style={[styles.navLabel, tab === name && styles.navSelected]}>{name}</Text>
          </Pressable>
        ))}
      </View>
      <Text style={styles.footer}>NAATH · PRIVATE TEST BUILD · NOT A LIVE STORE</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F8F5F0" },
  header: { paddingHorizontal: 18, paddingVertical: 12, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderBottomWidth: 1, borderColor: "#E8E0D7" },
  brand: { fontSize: 27, fontWeight: "900", letterSpacing: 3, color: "#183B32" },
  tagline: { fontSize: 11, color: "#77716A", marginTop: 2 },
  cartBubble: { backgroundColor: "#E8EFEA", paddingHorizontal: 13, paddingVertical: 9, borderRadius: 20 },
  cartBubbleText: { color: "#183B32", fontWeight: "800" },
  content: { padding: 16, paddingBottom: 24 },
  hero: { backgroundColor: "#183B32", padding: 22, borderRadius: 18, marginBottom: 16 },
  heroEyebrow: { color: "#D5B77A", fontSize: 10, fontWeight: "800", letterSpacing: 2 },
  heroTitle: { color: "#FFFFFF", fontSize: 25, fontWeight: "800", marginTop: 10, lineHeight: 31 },
  heroSub: { color: "#E7E8E2", marginTop: 8, fontSize: 13 },
  search: { backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E7E0D8", borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, color: "#222", marginBottom: 12 },
  categories: { marginBottom: 18, flexGrow: 0 },
  chip: { paddingHorizontal: 16, paddingVertical: 9, borderRadius: 20, backgroundColor: "#EEE9E2", marginRight: 8 },
  chipActive: { backgroundColor: "#183B32" },
  chipText: { color: "#4F4A43", fontWeight: "600" },
  chipTextActive: { color: "#FFFFFF" },
  sectionRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  sectionTitle: { fontSize: 16, fontWeight: "800", color: "#25251F" },
  productGrid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" },
  productCard: { width: "48.5%", backgroundColor: "#FFFFFF", padding: 10, borderRadius: 14, marginBottom: 12, borderWidth: 1, borderColor: "#EEE8E0" },
  productArt: { height: 105, backgroundColor: "#F0EAE1", borderRadius: 10, alignItems: "center", justifyContent: "center", marginBottom: 9 },
  productEmoji: { fontSize: 43 },
  productName: { color: "#292821", fontWeight: "700", fontSize: 13, marginBottom: 4 },
  muted: { color: "#77736D", fontSize: 11, marginBottom: 5 },
  price: { color: "#183B32", fontWeight: "900", marginVertical: 7, fontSize: 13 },
  button: { backgroundColor: "#183B32", borderRadius: 10, paddingVertical: 11, paddingHorizontal: 12, alignItems: "center", marginTop: 8 },
  buttonText: { color: "#FFFFFF", fontWeight: "800", fontSize: 12 },
  secondaryButton: { backgroundColor: "#EEE9E2" },
  secondaryButtonText: { color: "#183B32" },
  pageTitle: { fontSize: 23, fontWeight: "900", color: "#183B32", marginBottom: 16 },
  empty: { color: "#77736D", backgroundColor: "#FFFFFF", padding: 18, borderRadius: 12, lineHeight: 22 },
  lineItem: { flexDirection: "row", backgroundColor: "#FFFFFF", padding: 13, borderRadius: 13, marginBottom: 10, alignItems: "center" },
  lineEmoji: { fontSize: 35, marginRight: 13 },
  qtyRow: { flexDirection: "row", alignItems: "center", marginTop: 5 },
  qtyButton: { width: 29, height: 29, borderRadius: 8, backgroundColor: "#EEE9E2", alignItems: "center", justifyContent: "center" },
  qty: { paddingHorizontal: 12, fontWeight: "800" },
  totalRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginVertical: 17 },
  input: { backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E7E0D8", borderRadius: 10, paddingHorizontal: 13, paddingVertical: 12, marginBottom: 10, color: "#222" },
  fieldLabel: { color: "#36342E", fontWeight: "800", marginTop: 8, marginBottom: 7, fontSize: 13 },
  choiceRow: { flexDirection: "row", marginBottom: 10 },
  choice: { borderWidth: 1, borderColor: "#DDD5CB", borderRadius: 10, padding: 10, marginRight: 7, flex: 1, alignItems: "center" },
  choiceActive: { backgroundColor: "#E4EEE7", borderColor: "#183B32" },
  choiceText: { color: "#57534D", fontSize: 12, fontWeight: "600" },
  choiceTextActive: { color: "#183B32", fontWeight: "900" },
  paymentChoice: { borderWidth: 1, borderColor: "#DDD5CB", padding: 12, borderRadius: 10, marginBottom: 7 },
  disclaimer: { color: "#81796F", fontSize: 10, lineHeight: 15, marginTop: 8 },
  orderCard: { backgroundColor: "#FFFFFF", borderRadius: 14, padding: 16 },
  orderRef: { color: "#183B32", fontWeight: "900", marginBottom: 8 },
  progress: { height: 7, borderRadius: 5, backgroundColor: "#E7E0D8", marginTop: 15, overflow: "hidden" },
  progressFill: { height: 7, width: "25%", backgroundColor: "#2C765D" },
  panel: { backgroundColor: "#FFFFFF", padding: 15, borderRadius: 14, marginTop: 14 },
  bodyText: { color: "#57534D", marginTop: 8, fontSize: 13 },
  nav: { flexDirection: "row", justifyContent: "space-around", paddingVertical: 9, borderTopWidth: 1, borderColor: "#E8E0D7", backgroundColor: "#FFFFFF" },
  navItem: { alignItems: "center", minWidth: 60 },
  navIcon: { color: "#827D74", fontSize: 19 },
  navLabel: { color: "#827D74", fontSize: 10, marginTop: 2 },
  navSelected: { color: "#183B32", fontWeight: "900" },
  footer: { textAlign: "center", fontSize: 8, letterSpacing: 1, color: "#8B857C", paddingBottom: 5, backgroundColor: "#FFFFFF" },
});
